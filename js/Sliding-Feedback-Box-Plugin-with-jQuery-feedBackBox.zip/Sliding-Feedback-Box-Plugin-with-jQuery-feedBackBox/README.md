feedBackBox
===========

A small feedback box realized as jQuery Plugin.

![image alt][1]

License Terms
--------
**[The MIT License (MIT)][2]**

jQuery Plugin Registry
--------
**[jQuery feedBackBox][3]**



  [1]: https://raw.github.com/jwillmer/feedBackBox/master/demo_screenshot.png
  [2]: http://opensource.org/licenses/MIT
  [3]: http://plugins.jquery.com/feedBackBox/
